package com.example.kiit.a1705914_lab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity implements View.OnClickListener {
Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        b1=findViewById(R.id.button3);
        b2=findViewById(R.id.button4);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v==b1)
        {
            Toast.makeText(this, "yes is pressed", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(this, "No is pressed", Toast.LENGTH_LONG).show();
        }

    }
}
