package com.example.kiit.a1705914_lab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
    }

    public void yes(View view) {
        Toast.makeText(this,"Yes is pressed",Toast.LENGTH_LONG).show();
    }

    public void no(View view) {
        Toast.makeText(this,"No is pressed",Toast.LENGTH_LONG).show();
    }
}
