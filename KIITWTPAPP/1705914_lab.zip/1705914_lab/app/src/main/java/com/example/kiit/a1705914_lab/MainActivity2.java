package com.example.kiit.a1705914_lab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
EditText e1,e2;
TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        e1=findViewById(R.id.editText);
        e2=findViewById(R.id.editText2);
        tv=findViewById(R.id.textView);
    }

    public void add(View view) {
        tv.setText("Sum is "+(Integer.parseInt(e1.getText().toString())+Integer.parseInt(e2.getText().toString())));
    }
}
