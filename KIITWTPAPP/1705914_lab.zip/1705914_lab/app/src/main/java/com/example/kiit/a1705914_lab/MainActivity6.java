package com.example.kiit.a1705914_lab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity6 extends AppCompatActivity {
    int noofPizzas = 0;
    int noofChoco = 0;
    int noofBurger = 0;
    int cost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);


        // public void addtocart(View view) {
        final CheckBox pizza = findViewById(R.id.checkBox3);
        final TextView tv = findViewById(R.id.textView13);
       final CheckBox choco = findViewById(R.id.checkBox4);
       final CheckBox burger = findViewById(R.id.checkBox5);
       final EditText e1 = findViewById(R.id.editText4);
       final EditText e2 = findViewById(R.id.editText5);
        final EditText e3 = findViewById(R.id.editText6);
        final Button cart = findViewById(R.id.button22);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pizza.isChecked()){
                    noofPizzas= Integer.parseInt(e1.getText().toString());
                }
                if(choco.isChecked()){
                    noofChoco=Integer.parseInt(e2.getText().toString());

                }
                if(burger.isChecked()){
                    noofBurger=Integer.parseInt(e3.getText().toString());
                }
                if(noofPizzas<=0 && noofChoco<=0 && noofBurger<=0)
                {
                    Toast.makeText(getApplicationContext(),"NO Quantity matched",Toast.LENGTH_SHORT).show();
                }
                else{
                    cost =(noofPizzas*200+noofChoco*50+noofBurger*60);
                   // tv.setText(cost);
                    Toast.makeText(getApplicationContext(), Integer.toString(cost), Toast.LENGTH_SHORT).show();

                }
            }
        });

    }
}


