package com.example.kiit.a1705914_lab;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Explicit1 extends AppCompatActivity {

    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explicit1);
        tv=findViewById(R.id.textView14);
        Bundle b=getIntent().getExtras();
        String s = null;
        if(b!=null)
        {
            s=b.getString("msg");
        }
        tv.setText("msg:"+s);
    }

    public void click(View view) {
        Intent i = new Intent(this, ExplicitIntent.class);
        startActivity(i);

    }
}
