package com.example.kiit.a1705914_lab;

import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Intent1234 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent1234);
    }

    public void web(View v) {
        String s="www.facebook.com";
        Uri u= Uri.parse("http://"+s);
        Intent i =new Intent(Intent.ACTION_VIEW,u);
        startActivity(i);
    }

    public void map(View v) {
        String s="puri";
        Uri u= Uri.parse("geo:?q="+s);
        Intent i =new Intent(Intent.ACTION_VIEW,u);
        startActivity(i);
    }

    public void call(View v) {
        String s="9988776655";
        Uri u= Uri.parse("tel:"+s);
        Intent i =new Intent(Intent.ACTION_VIEW,u);
        startActivity(i);
    }

    public void camera(View v) {
        Intent i =new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivity(i);
    }

}
