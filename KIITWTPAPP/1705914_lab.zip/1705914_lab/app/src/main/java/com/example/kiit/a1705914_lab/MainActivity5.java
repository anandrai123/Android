package com.example.kiit.a1705914_lab;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity5 extends AppCompatActivity implements View.OnClickListener {
    TextView tv;
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        tv=findViewById(R.id.textView2);
        b1=findViewById(R.id.button6);
        b2=findViewById(R.id.button7);
        b3=findViewById(R.id.button8);
        b4=findViewById(R.id.button9);
        b5=findViewById(R.id.button10);
        b6=findViewById(R.id.button11);
        b7=findViewById(R.id.button12);
        b8=findViewById(R.id.button13);
        b9=findViewById(R.id.button14);
        b10=findViewById(R.id.button15);
        b11=findViewById(R.id.button16);
        b12=findViewById(R.id.button17);
        b13=findViewById(R.id.button18);
        b14=findViewById(R.id.button19);
        b15=findViewById(R.id.button20);
        b16=findViewById(R.id.button21);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);
        b10.setOnClickListener(this);
        b11.setOnClickListener(this);
        b12.setOnClickListener(this);
        b13.setOnClickListener(this);
        b14.setOnClickListener(this);
        b15.setOnClickListener(this);
        b16.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {


    }
}
